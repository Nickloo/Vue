<template>
  <div class="body">
    <h1 class="text-center">404</h1>
  </div>
</template>

<script>
export default {
  name: 'home',
  components:{
  	
  },
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
