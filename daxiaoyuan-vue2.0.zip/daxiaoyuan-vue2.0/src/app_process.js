// const fs = require('fs');
// function finish(){
// 	console.log('文件读取完毕');
// }
// // process.nextTick(finish);
// setTimeout(finish,0)
// console.log(fs.readFileSync('./app_process.js').toString());
